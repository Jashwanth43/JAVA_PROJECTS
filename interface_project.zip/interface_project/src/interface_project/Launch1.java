package interface_project;
import java.util.Scanner;
interface calculator {
	void add();
	void sub();
}
class myCalculator implements calculator {
	

	@Override
	public void sub() {
		// TODO Auto-generated method stub
		int a,b,c;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of a:");
		a=sc.nextInt();
		System.out.println("enter the value of b:");
		b=sc.nextInt();
		c=a-b;
		System.out.println("The value of sub of a and b :"+c); 
	}

	@Override
	public void add() {
		// TODO Auto-generated method stub
		int a,b,c;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of a:");
		a=sc.nextInt();
		System.out.println("enter the value of b:");
		b=sc.nextInt();
		c=a+b;
		System.out.println("The value of add of a and b :"+c);  
		
	}
}
class myCalculator2 implements calculator {

	@Override
	public void add() {
		int a,b,c;
		a=10;
		b=20;
		c=a+b;
		System.out.println("The value of add of a and b :"+c);  
	}

	@Override
	public void sub() {
		// TODO Auto-generated method stub
		int a,b,c;
		a=100;
		b=200;
		c=a-b;
		System.out.println("The value of sub of a and b :"+c);
	}
	public void printer() {
		System.out.println("hello");
	}
}
class mainCalculator {
	public void permit(calculator c) {
		c.add();
		c.sub();
		
	}
}
public class Launch1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		myCalculator mc1=new myCalculator();
		myCalculator2 mc2=new myCalculator2();
		mainCalculator c=new mainCalculator();
		c.permit(mc1);
		c.permit(mc2);
		

	}

}
