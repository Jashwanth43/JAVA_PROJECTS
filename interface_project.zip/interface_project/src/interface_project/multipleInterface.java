package interface_project;

import java.util.Scanner;

interface calci1 {
	void add(int a,int b);
}
interface calci2 {
	void sub(int a,int b);
}
class childClass implements calci1,calci2 {

	@Override
	public void sub(int a, int b) {
		// TODO Auto-generated method stub
		int c;
		c=a-b;
		System.out.println("The value of sub of a and b :"+c);
	}

	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		int c;
		c=a+b;
		System.out.println("The value of add of a and b :"+c);  
	}



	
}
public class multipleInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		childClass c=new childClass();
		c.add(30, 20);
		c.sub(100, 85);

	}

}
