package interface_project;
interface calcu {
	void add();
	default void show() {
		System.out.println("Hello method having a new method in JAVA 8 by using default keyword");
	}
	static void test() {
		System.out.println("This is the static method in the interface");
	}
	default void t() {
		newtest();
	}
	//JAVA 9
	private void newtest() {
		System.out.println("This is a new private method that was implemented in JAVA9");
	}
}
class mycal2 {
	void sub () {
		int a=30;
		int b=20;
		int c=a-b;
		System.out.println(c);
	}
	void add() {
		int a=300;
		int b=200;
		int c=a+b;
		System.out.println(c);
	
	}
}
class Myc extends mycal2 implements calcu {

	@Override
	public void add() {
		// TODO Auto-generated method stub
		int a=30;
		int b=20;
		int c=a+b;
		System.out.println(c);
		
	}
	public void show() {
		System.out.println("This is overritten method from interface");
	}
}
public class launch3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Myc c=new Myc();
		Myc.test();
		c.t();
		c.show();
		c.add();
		c.sub();
	}

}
