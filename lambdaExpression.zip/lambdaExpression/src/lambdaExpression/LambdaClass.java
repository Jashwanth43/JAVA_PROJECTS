package lambdaExpression;
@FunctionalInterface
interface CLS {
	void getLength(String s,int a);
}
public class LambdaClass {

	public static void main(String[] args) {
		CLS c=(s,a) -> 
			System.out.println(s.length());	
		c.getLength("hello world",10);
	}

}
