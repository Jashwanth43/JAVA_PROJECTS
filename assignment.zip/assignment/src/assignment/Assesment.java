package assignment;
import java.sql.*;

public class Assesment {
    public static void main(String[] args) {
        Connection connection = null;
        try {
            // Load the SQLite JDBC driver
            Class.forName("org.sqlite.JDBC");
            
            // Establish a connection to the SQLite database
            String url = "jdbc:sqlite:/path/to/database.db";
            connection = DriverManager.getConnection(url);
            
            System.out.println("Connection to SQLite database established.");
            
            // Create a new database named "university"
            Statement statement = connection.createStatement();
            statement.executeUpdate("CREATE DATABASE IF NOT EXISTS university");
            
            System.out.println("Database \"university\" created successfully.");
            
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getClass().getName() + ": " + e.getMessage());
            }
        }
    }
}
