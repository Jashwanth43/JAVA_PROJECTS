module areaOfShapes {
}