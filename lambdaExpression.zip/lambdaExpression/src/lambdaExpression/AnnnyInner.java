package lambdaExpression;
@FunctionalInterface
interface alpha1 {
	void beta();
}
public class AnnnyInner {

	public static void main(String[] args) {
		alpha1 a=new alpha1(){
			
			@Override
			public void beta() {
				// TODO Auto-generated method stub
				System.out.println("This is a inner class");
			}
		};
		a.beta();
	}

}
