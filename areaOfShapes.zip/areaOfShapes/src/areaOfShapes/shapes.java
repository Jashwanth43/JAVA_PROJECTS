package areaOfShapes;

import java.util.Scanner;

abstract class  parentShape {
	float area;
	abstract void input();
	abstract void compute();
	 void display() {
		 System.out.println("The area is "+area);
	 }
}
final class rectangle1 extends parentShape{
	float length;
	float breadth;
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("pleaser enter the length of rectangle");
		length=sc.nextFloat();
		System.out.println("pleaser enter the breadth of rectangle");
		breadth=sc.nextFloat();
	}
	void compute() {
		
		area=length*breadth;
		
	}
}
class square1 extends parentShape {
	float length;
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("pleaser enter the length of square");
		length=sc.nextFloat();
		
	}
	void compute() {
		
		area=length*length;
		
	}
}
class circle1 extends parentShape {
	float radius;
	final float pi=3.14f;
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("pleaser enter the radius of circle");
		radius=sc.nextFloat();
		
	}
	void compute() {
		
		area=pi*(radius*radius);
		
	}
}

class Geometery {
	void permit(parentShape p) {
		p.input();
		p.compute();
		p.display();
	}
}
public class shapes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Geometery G=new Geometery();
		rectangle1 r=new rectangle1();
		square1 s=new square1();
		circle1 c=new circle1();
		G.permit(r);
		G.permit(s);
		G.permit(c);

	}

}
