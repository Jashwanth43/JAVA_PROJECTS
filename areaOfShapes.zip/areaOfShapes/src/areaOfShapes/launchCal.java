package areaOfShapes;
//this project is without using oops 
import java.util.*;
final class rectangle {
	float length;
	float breadth;
	float area;
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("pleaser enter the length of rectangle");
		length=sc.nextFloat();
		System.out.println("pleaser enter the breadth of rectangle");
		breadth=sc.nextFloat();
	}
	void compute() {
		
		area=length*breadth;
		
	}
	void display() {
		System.out.println("Area of rectange is "+area);
	}

}
class square {
	float length;
	float area;
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("pleaser enter the length of square");
		length=sc.nextFloat();
		
	}
	void compute() {
		
		area=length*length;
		
	}
	void display() {
		System.out.println("Area of square is "+area);
	}
}
 class circle {
	float radius;
	float area;
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("pleaser enter the radius of circle");
		radius=sc.nextFloat();
		
	}
	void compute() {
		
		area=3.14f*(radius*radius);
		
	}
	void display() {
		System.out.println("Area of circle is "+area);
	}
}
public class launchCal {

	public static void main(String[] args) {
		rectangle r=new rectangle();
		square s=new square();
		circle c=new circle();
		r.input();
		r.compute();
		r.display();
		
		s.input();
		s.compute();
		s.display();
		
		c.input();
		c.compute();
		c.display();
	}

}
